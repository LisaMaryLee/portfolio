# GCP Big Data Projects

Samples from Google Cloud labs and real-world data engineering tasks.